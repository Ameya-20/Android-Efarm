package com.example.efarm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button controllerbtn =findViewById(R.id.contbtn);
        Button exit = findViewById(R.id.exitbtn);

        controllerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent minimodelintent = new Intent(Dashboard.this, Controller.class);
                startActivity(minimodelintent);
                finish();
            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent minimodelintent = new Intent(Dashboard.this, homepage.class);
                startActivity(minimodelintent);
                finish();
            }
        });

    }
}
